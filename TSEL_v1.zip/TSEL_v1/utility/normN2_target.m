function [Xt,Yt,trIdx,teIdx,LOC] = normN2_target(target,idx,ratio)

Xt = target(1:end-1,:);
Yt = target(end,:);
Yt(Yt>1) = 1;

posind = find(Yt == 1); % defective
negind = find(Yt == 0); % non-defectuve
temp1 = Xt(:,posind);
temp2 = Xt(:,negind);
Xt = [temp1, temp2];
LOC = Xt(1,:);

% zscore normalization
Xt = zscore(Xt,[],2); 
Yt = [ones(1,size(temp1,2)), zeros(1,size(temp2,2))];

% split training index and test index
trIdxPos = idx(1:floor(ratio*length(posind)));
teIdxPos = setdiff(idx(1:length(posind)),trIdxPos);
trIdxNeg = idx(length(posind)+1:length(posind)+floor(ratio*length(negind)));
teIdxNeg = setdiff(idx(length(posind)+1:end),trIdxNeg);

trIdx = [trIdxPos,trIdxNeg];
teIdx = [teIdxPos,teIdxNeg];





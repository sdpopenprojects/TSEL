function measure = performanceMeasure(test_label, predict_label)

% True Positive: the number of defective modules predicted as defective
% False Negative: the number of defective modules predicted as non-defective
% False Positive: the number of non-defective modules predictied as defective
% Ture Nagative: the number of non-defective modules predictied as non-defective

% confusion matrix
%  
%                            defective             non-defective (true class)
%  ---------------------------------------------------------------------------
%   predicted    defective        TP                   FP (Type I error)
%    class       -----------------------------------------------------------
%                non-defective    FN (Type II error)   TN
%  ---------------------------------------------------------------------------
% 
% 
% test_label: actual label of testset 
% predict_label: predicted label of testset
%
%

[X_coordi,Y_coordi,T_thre,AUC] = perfcurve(test_label',predict_label',1);

predict_label(predict_label>0.5) = 1;
predict_label(predict_label<=0.5) = 0;

test_total = length(test_label);
posNum = sum(test_label == 1); % defective
negNum = test_total - posNum;

pos_index = test_label == 1;
pos = test_label(pos_index);
pos_predicted = predict_label(pos_index);
FN = sum(pos ~= pos_predicted); % Type II error

neg_index = test_label == 0; % defective free
neg = test_label(neg_index);
neg_predicted = predict_label(neg_index);
FP = sum(neg ~= neg_predicted);  % Type I error

TP = posNum-FN;
TN = negNum-FP;

pd_recall = 0;
pf = 0;
precision = 0;
F_measure = 0;

if TP+FN ~= 0
    pd_recall = TP/(TP+FN); % TPR
end

if FP+TN ~= 0
    pf = FP/(FP+TN); % FPR
end

if TP+FP ~= 0
    precision = TP/(TP+FP); 
end

if (pd_recall+precision) ~= 0
    F_measure = 2 * pd_recall * precision / (pd_recall+precision);
end

% % balance = 1-sqrt(((0-pf).^2+(1-pd).^2)/2)
bal = 1- ( sqrt((0-pf).^2+(1-pd_recall).^2) ./ sqrt(2) );

% display
measure = [AUC, F_measure, bal];

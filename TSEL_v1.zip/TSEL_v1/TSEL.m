function measure = TSEL(data,Xt,Yt,K,kpar,r)
% 
% data: source data sets, prediciton combiantion of target 
% Xt: target data
% Yt: actual target label
% K: number of sampling
% kpar: kernel parameters
% r: rank of ICD algorithm
% 

% number of predcition combinations
v = size(data,1);

measure = [];
for i=1:v
    source = data{i,1};
    % normalize source data
    [Xs,Ys] = normN2_source(source);
     
    % statistic defective and non-defective instances
    posXs = Xs(:,Ys==1); % defective
    negXs = Xs(:,Ys==0); % non-defective
    npos = size(posXs,2);
    nneg = size(negXs,2);
    NN = size(Xs,2);
    samw = [repmat(nneg/NN,npos,1); repmat(npos/NN,nneg,1)];
    
    rng('default')
    emkca_label = [];
    
    for k = 1:K  % number of sampling 
        % resample with replacement sampling, bootstrapping
        [sXs,samIdx] = datasample(Xs',NN,'Weights',samw);
        sXs = sXs';
        sYs = Ys(samIdx);
        [sXs,sYs] = alignment(sXs,sYs);
        
        kca_label = [];
        w = []; % weight for EMKCA predictors
        
        for j=1:length(kpar) % number of kernels
            % kernel correlation alignment
            [nXs,nXt] = KCA(sXs,Xt,kpar(j),r); 
            nXs = real(nXs); nXt = real(nXt);
            nXs = nXs*diag(1./sqrt(sum(nXs.^2))); nXs(isnan(nXs)) = 0;
            nXt = nXt*diag(1./sqrt(sum(nXt.^2))); nXt(isnan(nXt)) = 0;
            
            % compute weight
            dist = pdist2(nXs, nXt);
            d = mean(mean(dist));
            w = [w, 1.0/d];

            % LR calssifier
            model = train(sYs',sparse(nXs),'-s 0 -c 1 -B -1 -q'); % num * fec
            [predict_label, ~, ~] = predict(Yt',sparse(nXt),model,'-b 1');
            kca_label = [kca_label; predict_label'];
        end

        w = w/sum(w); % normalize weight
        
        lab = w*kca_label; % weighted combination of each KCA
        emkca_label = [emkca_label; lab]; 
    end 
    
    % ensemble multiple EMKCA predictiors
    tsel_label = mean(emkca_label,1);  
    
    % calculate performance measures
    mea = performanceMeasure(Yt,tsel_label); 
    measure = [measure; mea];
end


% % put all defective modules in the front, all non-defective modules in the back
function [X,Y] = alignment(x,y)
pidx = find(y == 1);
nidx = find(y == 0);

pdata = x(:,pidx);
ndata = x(:,nidx);

X = [pdata, ndata];
Y = [ones(1,length(pidx)), zeros(1,length(nidx))];


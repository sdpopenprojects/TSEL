% % % 
%  an example: predict CM1 project by using other heterogeneous source projects
% % % 

clear all
close all
clc

addpath('.\liblinear\');
addpath('.\utility\');

% load target data
load('CM1.mat')
target_data = target{1,1};
target_name = target{1,2};
target_ridx = target{1,3}; % random index

% load source data
load('CM1_source.mat');

savePath = '.\result\';
sp = [savePath,target_name];
if exist(sp,'dir') == 0
    mkdir(sp);
end
    
Rep = 50;
ratio = 0.5; % two-fold

K = 10; % number of sampling 
kpar = [2^-4 2^-3 2^-2 2^-1 1 2 2^2 2^3 2^4 0]; % number of kernels
r = 60; % rank r in ICD algorithm 

for loop = 1:Rep
    % split target data
    [fea,label,trIdx,teIdx] = normN2_target(target_data,target_ridx(loop,:),ratio);

    for j=1:2 % two-fold cross validation
        if j==1
            Xt = fea(:,teIdx);
            Yt = label(teIdx);
        else
            Xt = fea(:,trIdx);
            Yt = label(trIdx);
        end

        count = 2*(loop-1)+j;
        measure = TSEL(source,Xt,Yt,K,kpar,r);
        
        save([sp,'\',num2str(count), '.mat'], 'measure');
    end
end

disp('done !')

